package com.demoairline.AirlineManagement.service;

import com.demoairline.AirlineManagement.response.AirLineResponse;
import com.demoairline.AirlineManagement.response.AirLinesResponse;

public interface AirlineService {

	AirLinesResponse getAirlines(Integer pageSize, Integer pageNumber);

	AirLineResponse getAirlinesByAirlinId(Long airlineId);

}
