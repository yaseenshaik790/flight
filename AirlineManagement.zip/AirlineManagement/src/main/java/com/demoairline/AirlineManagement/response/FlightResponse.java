package com.demoairline.AirlineManagement.response;

import com.demoairline.AirlineManagement.entity.Flight;
import com.fasterxml.jackson.annotation.JsonProperty;

public class FlightResponse {

	@JsonProperty("flight")
	private Flight flight;
	@JsonProperty("statusCode")
	private Integer statusCode = 666;
	public FlightResponse(Flight flight, Integer statusCode) {
		super();
		this.flight = flight;
		this.statusCode = statusCode;
	}

	
}
