package com.demoairline.AirlineManagement.exception;

public class AirLinesNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private static final Integer STATUS_CODE = 661;

	public AirLinesNotFoundException() {
		super("Airlines not found");
	}

	public Integer getStatusCode() {
		return STATUS_CODE;
	}

}
