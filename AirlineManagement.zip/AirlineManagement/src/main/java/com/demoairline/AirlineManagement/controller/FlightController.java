package com.demoairline.AirlineManagement.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demoairline.AirlineManagement.exception.FlightNotFoundException;
import com.demoairline.AirlineManagement.exception.FlightsNotFoundException;
import com.demoairline.AirlineManagement.response.AirLinesResponse;
import com.demoairline.AirlineManagement.response.FlightResponse;
import com.demoairline.AirlineManagement.response.FlightsResponse;
import com.demoairline.AirlineManagement.service.FlightService;

@RestController
@RequestMapping("/flights")
public class FlightController {

	@Autowired
	private FlightService flightService;

	private Logger logger = LoggerFactory.getLogger(FlightController.class);

	/**
	 * 
	 * @throws FlightNotFoundException
	 * @param flightId
	 * @return flight details through flight Id
	 */
	@GetMapping("/{flightId}")
	public ResponseEntity<FlightResponse> getFlightByFlightId(@PathVariable("flightId") Long flightId) {

		logger.info("Fetching flight details");

		return new ResponseEntity<>(flightService.getFlightByFlightId(flightId), HttpStatus.OK);
	}
	/**
	 * 
	 * @param pageSize
	 * @param pageNumber
	 * @return all flights
	 * @throws FlightsNotFoundException
	 */

	@GetMapping("")
	public ResponseEntity<FlightsResponse> getFlights(@RequestParam Integer pageSize,
			@RequestParam Integer pageNumber) {

		logger.info("Fetching airlines details");

		return new ResponseEntity<>(flightService.getFlights(pageSize, pageNumber), HttpStatus.OK);
	}

}
