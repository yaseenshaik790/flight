package com.demoairline.AirlineManagement.exception;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.demoairline.AirlineManagement.response.ErrorResponse;

@ControllerAdvice
public class GloblalException extends ResponseEntityExceptionHandler {

	protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body,
			org.springframework.http.HttpHeaders headers, HttpStatus status, WebRequest request) {

		if (ex instanceof MethodArgumentNotValidException) {

			MethodArgumentNotValidException exception = (MethodArgumentNotValidException) ex;

			List<String> errorList = exception.getBindingResult()

					.getFieldErrors()

					.stream()

					.map(fieldError -> fieldError.getDefaultMessage())

					.collect(Collectors.toList());

			ErrorResponse errorDetails = new ErrorResponse("this is a message from handler", errorList, 856);

			return super.handleExceptionInternal(ex, errorDetails, headers, status, request);

		}
		return super.handleExceptionInternal(ex, body, headers, status, request);

	}

	@ExceptionHandler(FlightNotFoundException.class)
	public ResponseEntity<Object> flightNotFoundException(FlightNotFoundException flightNotFoundException) {

		ErrorResponse errorResponse = new ErrorResponse(flightNotFoundException.getMessage(),
				flightNotFoundException.getStatusCode());

		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);

	}

	@ExceptionHandler(FlightsNotFoundException.class)
	public ResponseEntity<Object> flightsNotFoundException(FlightsNotFoundException flightsNotFoundException) {

		ErrorResponse errorResponse = new ErrorResponse(flightsNotFoundException.getMessage(),
				flightsNotFoundException.getStatusCode());

		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);

	}

	@ExceptionHandler(AirLineNotFoundException.class)
	public ResponseEntity<Object> airLineNotFoundException(AirLineNotFoundException airLineNotFoundException) {

		ErrorResponse errorResponse = new ErrorResponse(airLineNotFoundException.getMessage(),
				airLineNotFoundException.getStatusCode());

		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);

	}

	@ExceptionHandler(AirLinesNotFoundException.class)
	public ResponseEntity<Object> airLinesNotFoundException(AirLinesNotFoundException airLinesNotFoundException) {

		ErrorResponse errorResponse = new ErrorResponse(airLinesNotFoundException.getMessage(),
				airLinesNotFoundException.getStatusCode());

		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);

	}

}
