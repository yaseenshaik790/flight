package com.demoairline.AirlineManagement.exception;

public class AirLineNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private static final Integer STATUS_CODE = 661;

	public AirLineNotFoundException(Long airlineId) {
		super("Airline not found with an airline id: " + airlineId);
	}

	public Integer getStatusCode() {
		return STATUS_CODE;
	}
}
