package com.demoairline.AirlineManagement.exception;

public class FlightNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private static final Integer STATUS_CODE = 661;

	public FlightNotFoundException(Long flightId) {
		super("Flight not found with an id: " + flightId);
	}

	public Integer getStatusCode() {
		return STATUS_CODE;
	}

}
