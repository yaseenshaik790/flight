package com.demoairline.AirlineManagement.service;

import com.demoairline.AirlineManagement.response.FlightResponse;
import com.demoairline.AirlineManagement.response.FlightsResponse;

public interface FlightService {

	FlightResponse getFlightByFlightId(Long flightId);

	FlightsResponse getFlights(Integer pageSize, Integer pageNumber);

}
