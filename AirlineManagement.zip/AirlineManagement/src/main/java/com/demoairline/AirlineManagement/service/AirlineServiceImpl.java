package com.demoairline.AirlineManagement.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.demoairline.AirlineManagement.entity.Airline;
import com.demoairline.AirlineManagement.exception.AirLineNotFoundException;
import com.demoairline.AirlineManagement.exception.AirLinesNotFoundException;
import com.demoairline.AirlineManagement.repository.AirlineRepository;
import com.demoairline.AirlineManagement.response.AirLineResponse;
import com.demoairline.AirlineManagement.response.AirLinesResponse;

@Service
@Transactional
public class AirlineServiceImpl implements AirlineService {

	@Autowired
	private AirlineRepository airlineRepository;

	public AirLinesResponse getAirlines(Integer pageSize, Integer pageNumber) {
		
		PageRequest pageRequest = PageRequest.of(pageNumber, pageSize, Sort.Direction.ASC, "airlineId");

		List<Airline> airlines = airlineRepository.findAll(pageRequest).getContent();
		if (airlines.isEmpty()) {
			throw new AirLinesNotFoundException();
		}
		AirLinesResponse airLinesResponse = new AirLinesResponse(airlines, airlines.size());

		return airLinesResponse;
	}

	public AirLineResponse getAirlinesByAirlinId(Long airlineId) {

		Optional<Airline> airline = airlineRepository.findById(airlineId);
		if (!airline.isPresent()) {
			throw new AirLineNotFoundException(airlineId);
		}
		AirLineResponse airLineResponse = new AirLineResponse(airline.get(), 661);

		return airLineResponse;
	}

}
