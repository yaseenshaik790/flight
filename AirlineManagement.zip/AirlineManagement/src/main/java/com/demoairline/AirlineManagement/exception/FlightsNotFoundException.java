package com.demoairline.AirlineManagement.exception;

public class FlightsNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private static final Integer STATUS_CODE = 669;

	public FlightsNotFoundException() {
		super("Flights not found");
	}

	public Integer getStatusCode() {
		return STATUS_CODE;
	}

}
