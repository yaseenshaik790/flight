package com.demoairline.AirlineManagement.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.demoairline.AirlineManagement.dto.FlightDto;
import com.demoairline.AirlineManagement.entity.Flight;
import com.demoairline.AirlineManagement.exception.FlightNotFoundException;
import com.demoairline.AirlineManagement.exception.FlightsNotFoundException;
import com.demoairline.AirlineManagement.repository.FlightRepository;
import com.demoairline.AirlineManagement.response.FlightResponse;
import com.demoairline.AirlineManagement.response.FlightsResponse;

@Service
@Transactional
public class FlightServiceImpl implements FlightService {

	@Autowired
	private FlightRepository flightRepository;

	public FlightResponse getFlightByFlightId(Long flightId) {

		Optional<Flight> flight = flightRepository.findById(flightId);

		if (!flight.isPresent()) {
			throw new FlightNotFoundException(flightId);
		}

		FlightResponse flightResponse = new FlightResponse(flight.get(), 666);

		return flightResponse;
	}

	public FlightsResponse getFlights(Integer pageSize, Integer pageNumber) {

		PageRequest pageRequest = PageRequest.of(pageNumber, pageSize, Sort.Direction.ASC, "flightId");

		List<Flight> flights = flightRepository.findAll(pageRequest).getContent();

		if (flights.isEmpty()) {
			throw new FlightsNotFoundException();
		}

		List<FlightDto> flightDtos = flights.stream().map(flight -> {
			FlightDto flightDto = new FlightDto();
			BeanUtils.copyProperties(flight, flightDto);
			return flightDto;
		}).collect(Collectors.toList());
		FlightsResponse flightsResponse = new FlightsResponse(flightDtos, flights.size());

		return flightsResponse;
	}

}
